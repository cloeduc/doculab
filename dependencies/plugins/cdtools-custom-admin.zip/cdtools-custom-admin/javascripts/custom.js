jQuery(document).ready(function(){
	jQuery('#acf-field-classer_ma_documentation').attr('size', 20);
	jQuery('#acf-field-licence_projet-other').parent().html(jQuery('#acf-field-licence_projet-other'));
	jQuery('#acf-field-licence_projet-other').after('Autre');
	jQuery('.categorychecklist-holder').css('max-height','400px');
});
