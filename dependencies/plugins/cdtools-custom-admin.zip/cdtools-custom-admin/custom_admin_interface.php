<?php
/*
Plugin Name: CDTOOLS manage suported File Type
Description: Place code for wordpress admin customisation (remove metabox, add metabox, and others tricks...)
Version: 0.1
Author: Cloé DUC
*/

// plugin folder url
if(!defined('CDTOOLS_ADMIN_INTERFACE_URL')) {
	define('CDTOOLS_ADMIN_INTERFACE_URL', plugin_dir_url( __FILE__ ));
}

//Permet de supprimer des metaboxs en fonction du rôle de l'utilisateur
add_action( 'admin_init', 'remove_posts_metabox' );
add_action( 'wp_before_admin_bar_render', 'remove_top_admin_bar' );

function remove_posts_metabox() {
	$current_user = wp_get_current_user();
	if($current_user->caps['ressource']) {
		$post_types = get_post_types();
		foreach ($post_types as $key => $type) {
		    remove_meta_box( 'postexcerpt', $type, 'normal' ); // Excerpt Metabo
		    remove_meta_box( 'trackbacksdiv', $type, 'normal' ); // Trackback Metabox
		    remove_meta_box( 'postcustom', $type, 'normal' ); // Custom Fields Metabox
		    remove_meta_box( 'commentstatusdiv', $type, 'normal' ); // Comments Status Metabox
		    remove_meta_box( 'commentsdiv', $type, 'normal' ); // Comments Metabox
		    remove_meta_box( 'revisionsdiv', $type, 'normal' ); // Revisions Metabox
		    //remove_meta_box( 'authordiv', $type, 'normal' ); // Author metabox
		    remove_meta_box( 'slugdiv', $type,'normal' ); // Slug Metabox
		    remove_meta_box( 'tagsdiv-post_tag', $type,'side' ); // Tags metabox
		    //remove_meta_box( 'submitdiv', $type,'side' ); // Date, status, and update/save metabox 
		    remove_meta_box( 'categorydiv', $type,'side' ); // Categories metabox
		    remove_meta_box( 'postimagediv', $type,'side'); // Featured image metabox
		}
	}
}
 

// Remove WordPress Admin Bar Menu Items
function remove_top_admin_bar() {
	$current_user = wp_get_current_user();
	global $wp_admin_bar;
	if($current_user->caps['faclabuser']) {
	    
	// To remove WordPress logo and related submenu items
	   $wp_admin_bar->remove_menu('wp-logo');
	   $wp_admin_bar->remove_menu('about');
	   $wp_admin_bar->remove_menu('wporg');
	   $wp_admin_bar->remove_menu('documentation');
	   $wp_admin_bar->remove_menu('support-forums');
	   $wp_admin_bar->remove_menu('feedback');

	// To remove Site name/View Site submenu and Edit menu from front end
	  /* $wp_admin_bar->remove_menu('site-name');
	   $wp_admin_bar->remove_menu('view-site');
	   $wp_admin_bar->remove_menu('edit');*/

	// To remove Update Icon/Menu
	   $wp_admin_bar->remove_menu('updates');

	// To remove Comments Icon/Menu
	   $wp_admin_bar->remove_menu('comments');

	// To remove 'New' Menu
	   /*$wp_admin_bar->remove_menu('new-content');

	// To remove 'Howdy, user' Menu completely and Search field from front end
	   $wp_admin_bar->remove_menu('top-secondary');
	   $wp_admin_bar->remove_menu('search'); 

	// To remove 'Howdy, user' subMenus 
	   $wp_admin_bar->remove_menu('user-actions');
	   $wp_admin_bar->remove_menu('user-info');
	   $wp_admin_bar->remove_menu('edit-profile');   
	   $wp_admin_bar->remove_menu('logout');*/

	}
	$wp_admin_bar->remove_menu('wp_lightbox_bank_links');
}


wp_enqueue_script('custom-admin-js', CDTOOLS_ADMIN_INTERFACE_URL.'/javascripts/custom.js', 'jquery', 1, true);

/*
Ceci permet de manipuler en JS le contenu de la popup de  
*/
add_action( 'admin_footer-post-new.php', 'wpse_76048_script' );
add_action( 'admin_footer-post.php', 'wpse_76048_script' );

function wpse_76048_script()
{
	$sentence = "<strong>Attention</strong>, nous vous conseillons d\'uploder des images de haute qualité, d\'un <strong>minimum de 600px</strong> de large afin qu\'elles soient traitées de façon optimum par le système";
    ?>
<script>
jQuery(function($) {
	wp.media.view.Modal.prototype.on('open', function(){ 
		$('p.upload-instructions').html('<?php echo $sentence ?>');
		$('p.upload-instructions').css('color', 'red');
		$('.media-menu-item').on('click', function() {
			$('p.upload-instructions').html('<?php echo $sentence ?>');
			$('p.upload-instructions').css('color', 'red');
		});
	});
});
</script>
    <?php
}