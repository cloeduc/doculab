<?php
/**
 * @package doculab
 * Template Name: minimal for ajax
 */
?>
<?php 
	echo do_shortcode($post->post_content);
?>