<script>
jQuery(document).ready(function() {
    jQuery(document).delegate('#login-form', 'submit', function(event){
        /* Stop form from submitting normally */
        event.preventDefault();
        /* Clear result div*/
        var form = jQuery(this);
        /* Get some values from elements on the page: */
        var values = jQuery(this).serialize();

        /* Send the data using post and put the results in a div */
        jQuery.ajax({
            url: "<?php echo $loginpageurl; ?>",
            type: "post",
            data: values,
            success: function(data){
                form.parent().html(data);
            },
            error:function(){
                console.log("failure");
            }
            });
        return false;
        });
    jQuery(document).delegate('#forgotpassword .cleanlogin-form', 'submit', function(event){
        /* Stop form from submitting normally */
        event.preventDefault();
        /* Clear result div*/
        var form = jQuery(this);
        /* Get some values from elements on the page: */
        var values = jQuery(this).serialize();

        /* Send the data using post and put the results in a div */
        jQuery.ajax({
            url: "<?php echo $restorpage; ?>",
            type: "post",
            data: values,
            success: function(data){
                form.parent().parent().html(data);
            },
            error:function(){
                console.log("failure");
            }
            });
        return false;
        });

    jQuery(document).delegate('#registration .cleanlogin-form', 'submit', function(event){
        /* Stop form from submitting normally */
        event.preventDefault();
        /* Clear result div*/
        var form = jQuery(this);
        /* Get some values from elements on the page: */
        var values = jQuery(this).serialize();

        /* Send the data using post and put the results in a div */
        jQuery.ajax({
            url: "<?php echo $suscribepage; ?>",
            type: "post",
            data: values,
            success: function(data){
                form.parent().parent().html(data);
            },
            error:function(){
                console.log("failure");
            }
            });
        return false;
        });
});

</script>