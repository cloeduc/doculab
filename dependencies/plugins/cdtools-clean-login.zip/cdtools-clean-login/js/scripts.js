    jQuery('#registration .cleanlogin-form').validate({ // initialize the plugin
        rules: {
            email: {
                required: true,
               // email: true
            },
            username: {
                required: true,
            },
            pass1:{
                required: true,
            },
            pass2: {
                equalTo: "#pass1"
            }
        }
    });