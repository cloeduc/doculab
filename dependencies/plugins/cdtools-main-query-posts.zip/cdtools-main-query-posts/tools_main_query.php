<?php
/*
Plugin Name: CDTOOLS Customize main Query
Description:Usefull for customize the main Query Post (and add custom post type, for example)
Version: 0.1
Author: Cloé DUC
*/

/*
|--------------------------------------------------------------------------
| CONSTANTS
|--------------------------------------------------------------------------
*/

// plugin folder url
if(!defined('CDTOOLS_MAIN_QUERY_URL')) {
	define('CDTOOLS_MAIN_QUERY_URL', plugin_dir_url( __FILE__ ));
}

/*
 Cette fonction permet de renseigner quels post type requêter en home page
*/
function custom_post_request( $query ) {
    if ( ($query->is_home() or $query->is_tag() or $query->is_category())  && $query->is_main_query() ) {
        $query->set( 'post_type', array('post', 'projets', 'tutoriaux', 'outils') );
        $query->set('orderby', 'modified');
        //$query->set('orderby', 'modified');
    }
}
add_action( 'pre_get_posts', 'custom_post_request' );

?>