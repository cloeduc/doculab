<h1><?php echo $post->post_title; ?></h1>
<?php echo html_entity_decode($post->post_content, ENT_QUOTES); ?>