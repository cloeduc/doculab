<h1><?php echo $post->post_title ?></h1>
<?php the_content(); ?>