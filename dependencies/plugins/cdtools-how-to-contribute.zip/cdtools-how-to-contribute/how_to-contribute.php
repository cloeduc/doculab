<?php
/*
Plugin Name: CDTOOLS - How to contribute page
Description: Add frontend and backend page with editable how to contribute
Version: 0.1
Author: Cloé DUC
TODO : Faire une page de configuration qui permet de définir quelle est la page "HOW TO". Par défaut le plugin en créé une à l'activation.
*/

/*
|--------------------------------------------------------------------------
| CONSTANTS
|--------------------------------------------------------------------------
*/


if(!defined('HOWTO_URL')) {
	define('HOWTO_URL', plugin_dir_url( __FILE__ ));
}
if(!defined('OPTION_PAGE_NAME')) {
	define('OPTION_PAGE_NAME', 'how-to-contribute-page');
}
if(!defined('ADMIN_PAGE_SLUG')) {
	define('ADMIN_PAGE_SLUG', 'how-to-contribute');
}

/*
|--------------------------------------------------------------------------
| MAIN CLASS
|--------------------------------------------------------------------------
*/

class cd_tools_how_to_contribute {
 
	/*--------------------------------------------*
	 * Constructor
	 *--------------------------------------------*/
 
	/**
	 * Initializes the plugin by setting localization, filters, and administration functions.
	 */
	function __construct() {
		add_action('admin_menu', array( &$this,'cd_tools_register_menu'));
		//Définir les constantes accessibles à l'extérieur du plugin :
		if(!defined('CDTOOLS_HOWTO_ADMIN_PAGE_SLUG')) {
			define('CDTOOLS_HOWTO_ADMIN_PAGE_SLUG', ADMIN_PAGE_SLUG);
		}
		if(!defined('CDTOOLS_PLUGIN_OPTION_PAGE_NAME')) {
			define('CDTOOLS_PLUGIN_OPTION_PAGE_NAME', OPTION_PAGE_NAME);
		}
	} // end constructor

	function cd_tools_register_menu() {
		add_menu_page(
			'Comment contribuer ?', // le titre de la page
			'Contribuer ?',            // le nom de la page dans le menu d'admin
			'read',        // le rôle d'utilisateur requis pour voir cette page
			ADMIN_PAGE_SLUG,        // un identifiant unique de la page
			array( &$this,'cd_tools_how_to_contribute'),  // le nom d'une fonction qui affichera la page
			'dashicons-welcome-learn-more', 3
		);
	}
	
	function cd_tools_how_to_contribute() {
		$post = get_post(get_option(OPTION_PAGE_NAME));
		require('how_to_contribute_page.php');
	}

	public static function activate()
	{
		//L'option a déjà été configurée, le plugin a déjà été activé.
		if(get_option(OPTION_PAGE_NAME)) {
			$post = get_post(get_option(OPTION_PAGE_NAME));
			if($post->ID != 1) return;
		}

		global $user_ID;
		$page['post_type']    = 'page';
		$page['post_content'] = 'Put your page content here';
		$page['post_parent']  = 0;
		$page['post_author']  = $user_ID;
		$page['post_status']  = 'publish';
		$page['post_title']   = 'Comment contribuer ?';
		$page['slug'] = "comment-contribuer";
		$pageid = wp_insert_post ($page);
	if ($pageid == 0) {
	    // Do nothing
	} else {
			//Enregistre la page crée comme la page "How-to"
			add_option('how-to-contribute-page', $pageid);
		}
	}


	public static function deactivate()
	{
	} // END public static function deactivate
 
}
 
// instantiate plugin's class
$GLOBALS['cd_tools_how_to_contribute'] = new cd_tools_how_to_contribute();
register_activation_hook(__FILE__, array('cd_tools_how_to_contribute', 'activate'));
register_deactivation_hook(__FILE__, array('cd_tools_how_to_contribute', 'deactivate'));
?>