<?php
/*
Plugin Name: CDTOOLS setting default config
Description: Close comment, set permalink structure, add role... Don't panic you can set manually each configuration
Version: 0.1
Author: Cloé DUC
*/
const DEFAULT_USER_ROLE = 'faclabuser';

function default_config() {
	add_roles_on_plugin_activation();
	// Turn off comments
	if( '' != get_option( 'default_ping_status' ) ) {
		update_option( 'default_ping_status', '' );
	} // end if

	// Turn off pings
	if( '' != get_option( 'default_comment_status' ) ) {
		update_option( 'default_comment_status', '' );
	} // end if

	//set permalink format
	update_option( 'permalink_structure', '/%postname%/' );

	// user can register :) 
	update_option( 'users_can_register', 1);
	//set default role un registration
	update_option('default_role', DEFAULT_USER_ROLE); 
	
} // end example_disable_all_comments_and_pings

register_activation_hook( __FILE__, 'default_config');



function add_roles_on_plugin_activation() {
	$capabilities = array( 
		'read' => true, 
		'level_0' => true,
		'delete_published_posts' => true,
		'edit_posts' => true,
		'edit_private_posts' => true,
		'edit_published_posts' => true,
		'publish_posts' => true,
		'read_private_posts' => true,
		'unfiltered_upload' => true,
		'upload_files' => true,
		'delete_lexique' => true,
		'delete_others_lexique' => true,
 		'delete_others_tools' => true,
 		'delete_private_lexique' => true,
		 'delete_private_tools' => true,
		 'delete_published_lexique' => true,
		 'delete_published_tools' => true,
		 'delete_tools'=> true,
		 'edit_lexique' => true,
		 'edit_others_lexique' => true,
		 'edit_others_tools' => true,
		  'edit_private_lexique' => true,
		 'edit_private_tools' => true,
		 'edit_published_lexique' => true,
		 'edit_published_tools' => true,
		 'edit_tools' => true,
		 'list_roles' => true,
		'publish_lexique' => true,
		 'publish_tools' => true,
		 'read_lexique' => true,
		 'read_private_lexique' => true,
		 'read_private_tools' => true,
		 'read_tools' => true,
		 ); 
   add_role( DEFAULT_USER_ROLE, 'FabLab User', $capabilities );
}