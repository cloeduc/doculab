<?php
/**
 * Our custom dashboard page
 */

/** WordPress Administration Bootstrap */

require_once( ABSPATH . 'wp-load.php' );
add_filter('the_content', 'do_shortcode', 11);
	$current_user = wp_get_current_user();
	$post_types = get_post_types();
	$drafts = array();
	foreach($post_types as $type)
	{
		$drafts = array_merge($drafts, query_posts('author='.$current_user->ID.'&post_status=draft&post_type='.$type));
	}
	add_filter('custom-dashboard', 'do_shortcode');
require_once( ABSPATH . 'wp-admin/admin.php' );
require_once( ABSPATH . 'wp-admin/admin-header.php' );

?>
<div class="wrap about-wrap">

	<h1>La documentation, c'est bon, mangez en ! </h1>
	
	<div class="about-text">
		<strong>Félicitation</strong>, noble faclabuser ! Si tu lis ces lignes c'est que tu t'es engagé sur la voie de la documentation. Ce qui fait de toi, indéniablement, une personne <strong>bien</strong>
	</div>

	
	<div class="changelog">
	<?php if(isset($drafts[0])) :  ?>
		<h2>Mes articles en cours de rédaction: </h2>
		<table class="wp-list-table widefat fixed posts">
		<thead>
			<tr>
				<th>Article</th><th>Date de création</th><th>Denière modification</th>
			</tr>
		</thead>

			<?php foreach ($drafts as $draft): ?>
				<tr>
					<td><a href="post.php?post=<?php echo $draft->ID; ?>&action=edit"><?php echo $draft->post_title ?></a></td><td><?php echo $draft->post_date ?></td><td><?php echo $draft->post_modified ?></td>
				</tr>
			<?php endforeach; ?>
		</table>
	<?php endif; ?>
	</div>
	<div class="changelog">
		<h2>Contacter les administrateurs du site : </h2>
		<ul>
			<li><a href="admin.php?page=rwpm_send&recipient=Faclab&subject=[Bug Repport]">Reporter un bug</a></li>
			<li><a href="admin.php?page=rwpm_send&recipient=Faclab&subject=[New Cat]">Suggérer une nouvelle catégorie</a></li>
		</ul>
	</div>
	<div class="changelog">
		<h2>Comment fonctionne l'espace de contribution</h2>
		<h3>J'ai un projet (un objet)</h3>
			<p>Vous avez eu une idée, un matin (ou un soir, c'est pareil) et vous venez au faclab pour la réaliser. 
			Du simple bouton de manchette au robot lanceur de carottes (pourquoi pas), vous pouvez (devez!) expliquer votre démarche
			afin que n'importe qui in-da-world puisse suivre vos périgrinations, recherches et expérimentations. 
			Laissez les plans, bien sur, choisissez la licence, mais surtout, expliquez au reste du monde les difficultés rencontrées, les matériaux utilisés. </p>
		<h3>Je documente une technique (tutoriel)</h3>
		<p>
			Pas d'objet précis en vue, mais vous avez appris une technique incroyable pour planter des clous ou graver de l'alu avec un dremel. 
			Dans tous les cas, ça mérite d'être partagé et vous pouvez créer un tutoriel pour illustrer votre technique, qu'elle se répande et que n'importe qui in-da-world puisse faire comme vous.
		</p>
		<h3>Je documente une machine (outils)</h3>
		<p>
			"Bon, de quoi est ce que j'ai besoin pour utiliser la découpe vinyle, et d'abord, comment elle fonctionne ?"
		</p>
		<p>
			Pour répondre à cette question, vous pouvez soit passer au lab, soit consulter la documentation existante et voir si il n'existe pas des ressources internes pour connaitre le fonctionnement de telle ou telle machine, ses règles d'utlisation, ses règles de sécurité...
		</p>
		<p>L'article présent sur le site est incomplet ? Un bon moyen de participer, c'est d'y contribuer !  N'improte qui peut l'éditer, le retravailler, y ajouter du contenu. La communauté vous remercie ! </p>
		<h3>Je contribue au lexique</h3>
		<p>Pour se comprendre, il faut utiliser les mêmes mots. Vous avez appris le sens d'un mot en bricolant, n'hesitez pas à le saisir. Les définitions sont collaborative et n'importe qui peut les améliorer. Même vous. Surtout vous.</p>
	</div>
</div>