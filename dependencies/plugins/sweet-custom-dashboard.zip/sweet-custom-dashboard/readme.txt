=== Sweet Custom Dashboard ===
Author URI: http://remicorson/
Plugin URI: http://remicorson.com/sweet-custom-dashboard 
Contributors: corsonr
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=UAQZDW8V6HJUL
Tags: Remi Corson, corsonr, dashboard, metaboxe, metaboxes, customization, administration, panel, console
Requires at least: 3.0
Tested up to: 3.5
Stable Tag: 0.1

A nice plugin to start creating your own custom WordPress dashboard.

== Description ==

Too often customizing the WordPress dashboard is adding or removing metaboxes. With this plugin you can create your own WordPress dashboard containing any HTML or PHP elements you want.
You're not limited anymore!

If you have suggestions or bugfixes for the plugin, please report them on [my website](https://remicorson.com).

**Languages**

This plugin has been translated into the following languages:

1. English

If you want to translate the plugin into your language, [contact me](http://remicorson/contact).

== Installation ==

1. Activate the plugin
2. Edit custom_dashboard.php
3. Go on your dashboard page
4. Take a coffee and relax, you did a great job!


== Screenshots ==

1. Preview a custom WordPress dashboard


== Changelog ==

= 0.1 =

* First release!

== Upgrade Notice ==

= 0.1 =

* First release!