<?php
/*
Plugin Name: CDTOOLS manage suported File Type
Description: Add or remove supported file type on upload.
Version: 0.1
Author: Cloé DUC
*/

// plugin folder url
if(!defined('CDTOOLS_MANAGE_FILE_TYPE_URL')) {
	define('CDTOOLS_MANAGE_FILE_TYPE_URL', plugin_dir_url( __FILE__ ));
}

// Added to extend allowed files types in Media upload
// can use mime type analyzer : http://mime.ritey.com/

add_filter('upload_mimes', 'custom_upload_mimes');

function custom_upload_mimes ( $existing_mimes=array() ) {
	$existing_mimes['eps'] = 'application/postscript';
	$existing_mimes['ai'] = 'application/illustrator';
	$existing_mimes['psd'] = 'application/photoshop';

	$existing_mimes['skp'] = 'application/vnd.sketchup';
	$existing_mimes['stl'] = 'application/vnd.ms-pkistl';
	$existing_mimes['dxf'] = 'application/x-autocad';
	$existing_mimes['dxf'] = 'application/x-autocad';

	$existing_mimes['svg'] = 'image/svg+xml';
	$existing_mimes['rbz'] = 'application/vnd.sketchup.skb';
	$existing_mimes['studio3'] = 'application/octet-stream';
	$existing_mimes['studio'] = 'application/octet-stream';
	$existing_mimes['ino'] = 'application/octet-stream';
	$existing_mimes['sb2'] = 'application/octet-stream';
	
	
	return $existing_mimes;
}
function tools_extract_file_extention($url)
{
	$tabUrl = parse_url($url);
	$fichier = basename ($tabUrl["path"]);
	$parts = array_reverse(explode('.', $fichier));
	return $parts[0];
}

?>